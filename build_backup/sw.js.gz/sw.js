var __wpo = {
  "assets": {
    "main": [
      "/7b0d08d59a375b9f0ef67610dceb2627.png",
      "/87b3f1080950710f9869ec820d2ac986.png",
      "/1f1edbae6e0a9776ccfdba5b62edb62a.jpg",
      "/ccf9910a5b10d398025419c16f27c320.png",
      "/f8146c4aa5f1aa8e248a177776f05c1e.jpg",
      "/e1b6094eaa535cd792570b4130934864.png",
      "/91972333a7df7bb304cd17a002baf6f2.jpg",
      "/favicon.ico",
      "/1a1a19e93cc372357b3520bc5a4bc84a.png",
      "/af99e33241df98dfa6d6a2839ec92db8.jpg",
      "/ebab5a12e84d47e7d141b0dd6cd519c1.jpg",
      "/b9389c1d72e6dd7911d536b310693398.jpg",
      "/74cfd3a49c8cf3b983361bcfe17b0fa3.jpg",
      "/e6191f1b99ca158a3e1609ce72798bb2.jpg",
      "/runtime.c14a0355ef0ba4d13917.js",
      "/"
    ],
    "additional": [
      "/npm.antd.379f66b6db198c5799ce.chunk.js",
      "/npm.lodash.110254d15be597a2c526.chunk.js",
      "/npm.ant-design.c493a67fd74bf8f8c476.chunk.js",
      "/npm.rc-util.bb9d95c04e510b7d6d82.chunk.js",
      "/npm.intl.35acf79a26cecc726e06.chunk.js",
      "/npm.react-big-calendar.fd91b53314253b5823ce.chunk.js",
      "/main.26571119c35bcd6430b5.chunk.js",
      "/npm.babel.26972ab2b6986b8fdb4e.chunk.js",
      "/npm.core-js.e74ac7ded616ac0b5a25.chunk.js",
      "/npm.countup.js.bb2c5a7e622b51671882.chunk.js",
      "/npm.json2mq.adb37d185a2519cfe5a8.chunk.js",
      "/npm.moment.1d14e4e377478124f07e.chunk.js",
      "/npm.rc-checkbox.5f1f50d273f7155d1197.chunk.js",
      "/npm.rc-picker.291c31592b033fe361ce.chunk.js",
      "/npm.react-avatar.8327b5dd607c3aa39178.chunk.js",
      "/npm.react-countup.7849c1a2e9f2a8e7f2e9.chunk.js",
      "/npm.react-google-charts.01664f220cea6bb1fb1e.chunk.js",
      "/npm.react-load-script.d06216af754a4b8f7ba2.chunk.js",
      "/npm.react-messenger-customer-chat.a2309da2dcc1efa9955d.chunk.js",
      "/npm.string-convert.88cfbbf8a0661446fd85.chunk.js",
      "/npm.warning.f33d48acb1164e1cb838.chunk.js",
      "/22.bf5a8f0113073ada6fb9.chunk.js",
      "/23.769c9da1ff26da95b58f.chunk.js",
      "/24.31290f611538f53e9c7a.chunk.js",
      "/25.b5f2705e5fee3e29516c.chunk.js",
      "/26.e8b8ce149d3a92198483.chunk.js",
      "/27.9189b72b2a082bfe6340.chunk.js",
      "/28.edca43a239def2a6b33f.chunk.js",
      "/29.31efe48c8cf0c5092784.chunk.js",
      "/30.6e6dc16ba99153210e70.chunk.js",
      "/31.c36894d2479bb84c5df3.chunk.js",
      "/32.48d4182902fd9c3766fb.chunk.js",
      "/33.87c1e790dccb87ac1244.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "68698d06e336446ad679ce75896135ec7b89a08d": "/7b0d08d59a375b9f0ef67610dceb2627.png",
    "a23d598a24330d8798f3f36dca89a941f66cadf6": "/87b3f1080950710f9869ec820d2ac986.png",
    "451c545b84aee683b1209f77ef7d825bc84d6d0e": "/1f1edbae6e0a9776ccfdba5b62edb62a.jpg",
    "d56418bd9c7e988af960a698e036f31c506924fc": "/ccf9910a5b10d398025419c16f27c320.png",
    "ac573bfcde906dae649cc7173cd2984decee58ab": "/f8146c4aa5f1aa8e248a177776f05c1e.jpg",
    "5c618c937edc2d97e282e538af2859c36a9e7012": "/e1b6094eaa535cd792570b4130934864.png",
    "41cbbc91e70b5c0200f26873da6790bd2e383bb5": "/91972333a7df7bb304cd17a002baf6f2.jpg",
    "9e97398be2d770dcaa6a4cf57a672ea18721b479": "/favicon.ico",
    "7ad3f8687592f4d86865de7e991e6f59b5a96ac4": "/1a1a19e93cc372357b3520bc5a4bc84a.png",
    "1d377e943440cc829392b3ad5c230f9585b19b7b": "/af99e33241df98dfa6d6a2839ec92db8.jpg",
    "32de435b36ff9dd42563446a280bdeaa86a5be8f": "/ebab5a12e84d47e7d141b0dd6cd519c1.jpg",
    "00d190a741372dcd4acd8e7f49a70f6b7d4284ba": "/b9389c1d72e6dd7911d536b310693398.jpg",
    "038146a5c7e372cf6d7d66ef43f5526d26d07311": "/74cfd3a49c8cf3b983361bcfe17b0fa3.jpg",
    "52c273654e5fbcc49ff825ee460fb34ff7475bc2": "/e6191f1b99ca158a3e1609ce72798bb2.jpg",
    "1ea6b235eda477d57753c0d868b1b2dd54dcd088": "/npm.antd.379f66b6db198c5799ce.chunk.js",
    "3df5dd9baadd0b5ad58fe382b8441ba3e96b177a": "/npm.lodash.110254d15be597a2c526.chunk.js",
    "8e0f419370479fb46346a359f89962772d96a7a8": "/npm.ant-design.c493a67fd74bf8f8c476.chunk.js",
    "87e1efc428c1784f90e4efed0360c9f00c8cd519": "/npm.rc-util.bb9d95c04e510b7d6d82.chunk.js",
    "509ecd96cded1e009c2c670a4f985ecd81ed600c": "/npm.intl.35acf79a26cecc726e06.chunk.js",
    "6cd6a89a7e65215e85ef0704f0eb16ee1d0cf15a": "/npm.react-big-calendar.fd91b53314253b5823ce.chunk.js",
    "c123abbbc2fe4e66764d723e689e070adf1ff9af": "/main.26571119c35bcd6430b5.chunk.js",
    "c778f65d54d8c72774b17cb126a3714a93c9005f": "/npm.babel.26972ab2b6986b8fdb4e.chunk.js",
    "393206b8c9ef1c7facfea3f06ad1a800ae21fe84": "/npm.core-js.e74ac7ded616ac0b5a25.chunk.js",
    "dc5217aec82b003888357568339759344c48ab04": "/npm.countup.js.bb2c5a7e622b51671882.chunk.js",
    "45df35cceb5af8df016389fd73f37e50b6d39947": "/npm.json2mq.adb37d185a2519cfe5a8.chunk.js",
    "b3e76c7c2656caf21c7e9ecb4abd5f648fd1b22a": "/npm.moment.1d14e4e377478124f07e.chunk.js",
    "00773ed7707fea9bbc7f0121ddf1ce8804f6e0e0": "/npm.rc-checkbox.5f1f50d273f7155d1197.chunk.js",
    "ef3e48ca9fa7d505e06a449345f246f1a60e423b": "/npm.rc-picker.291c31592b033fe361ce.chunk.js",
    "3a1e0bdbf7d6cba5ffa056e7bcba5a02daaf65c9": "/npm.react-avatar.8327b5dd607c3aa39178.chunk.js",
    "50fd56dc41acf45dea0c3cc26782f2cd93fa65d2": "/npm.react-countup.7849c1a2e9f2a8e7f2e9.chunk.js",
    "419a03193dc38e564a8cb45a33682ae0fe6382b3": "/npm.react-google-charts.01664f220cea6bb1fb1e.chunk.js",
    "1c8078cf8741688c5ff64e40b59c4e176f2d264c": "/npm.react-load-script.d06216af754a4b8f7ba2.chunk.js",
    "a3765394961eb1a7104d5e73f18af6aad481f621": "/npm.react-messenger-customer-chat.a2309da2dcc1efa9955d.chunk.js",
    "a7494e9cccf6bd38be3915e8cdd64b336f491590": "/npm.string-convert.88cfbbf8a0661446fd85.chunk.js",
    "5069a4b7f1417489a457d3f9d01ae2caf0d3b0c3": "/npm.warning.f33d48acb1164e1cb838.chunk.js",
    "97dbd0f985dad0dab3e8bf3afe523802365bb7f2": "/runtime.c14a0355ef0ba4d13917.js",
    "ed4fccaef5927874bd5df290f0a9bf49b1d7948e": "/22.bf5a8f0113073ada6fb9.chunk.js",
    "6d4f191ee3146ae6851e41f689773a9159ba8a9f": "/23.769c9da1ff26da95b58f.chunk.js",
    "7bc9d102e0b45c788a139e95efadbe8cb031e4cb": "/24.31290f611538f53e9c7a.chunk.js",
    "21713389a89b25b801e515784e733ec0ed2ed741": "/25.b5f2705e5fee3e29516c.chunk.js",
    "834655282094a9f4d7c071f62b5cc5fe820cc525": "/26.e8b8ce149d3a92198483.chunk.js",
    "da72c0e14f3f3bc78df5726f61f26cea1f786c80": "/27.9189b72b2a082bfe6340.chunk.js",
    "6799c58f7bfa5a392194f9b2ff2990a9b1b396c7": "/28.edca43a239def2a6b33f.chunk.js",
    "589af627775d8509b74500f525c83a1cf3a6db85": "/29.31efe48c8cf0c5092784.chunk.js",
    "f0d2db285e9da32c554e489f06a209901ab0c844": "/30.6e6dc16ba99153210e70.chunk.js",
    "66fac6af66b1980a388f0d1ab7a9f273405425e6": "/31.c36894d2479bb84c5df3.chunk.js",
    "0593433764efe811902f202c72e03610b09e4a3a": "/32.48d4182902fd9c3766fb.chunk.js",
    "b44c043134dc605364d0042490e3b20dbaa3eb64": "/33.87c1e790dccb87ac1244.chunk.js",
    "5f2dc22fabe2f01da4905b8d7400892dd7e63736": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2/20/2021, 8:29:39 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });